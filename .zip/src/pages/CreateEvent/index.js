import React from 'react'

const CreateEvent = () => {
    return (
        <div>CreateEvent</div>
    )
}

export default CreateEvent